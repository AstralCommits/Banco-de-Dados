-- MySQL dump 10.13  Distrib 8.0.46, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: confeccoes
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `avaliacoes_artesao`
--

DROP TABLE IF EXISTS `avaliacoes_artesao`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `avaliacoes_artesao` (
  `id` int NOT NULL AUTO_INCREMENT,
  `pedido_id` int NOT NULL,
  `artesao_id` int NOT NULL,
  `nota` tinyint NOT NULL,
  `comentario` varchar(500) DEFAULT NULL,
  `data_avaliacao` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_avaliacao_pedido` (`pedido_id`),
  KEY `fk_avaliacao_pedido_artesao` (`pedido_id`,`artesao_id`),
  KEY `idx_avaliacoes_artesao` (`artesao_id`),
  CONSTRAINT `fk_avaliacao_pedido_artesao` FOREIGN KEY (`pedido_id`, `artesao_id`) REFERENCES `pedido` (`id_pedido`, `id_confeccao`) ON DELETE RESTRICT,
  CONSTRAINT `chk_avaliacao_nota` CHECK ((`nota` between 1 and 5))
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `avaliacoes_artesao`
--

LOCK TABLES `avaliacoes_artesao` WRITE;
/*!40000 ALTER TABLE `avaliacoes_artesao` DISABLE KEYS */;
INSERT INTO `avaliacoes_artesao` VALUES (1,1,3,5,'Pecas dentro do prazo e com acabamento excelente.','2026-02-10 09:00:00'),(2,2,3,4,'Boa qualidade, pequeno atraso na entrega.','2026-02-18 14:10:00');
/*!40000 ALTER TABLE `avaliacoes_artesao` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `trg_avaliacao_pedido_entregue` BEFORE INSERT ON `avaliacoes_artesao` FOR EACH ROW BEGIN
    IF (SELECT ped_status FROM pedido WHERE id_pedido = NEW.pedido_id) <> 'ENTREGUE' THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Somente pedidos entregues podem ser avaliados.';
    END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `categoria`
--

DROP TABLE IF EXISTS `categoria`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categoria` (
  `id_categoria` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(60) NOT NULL,
  PRIMARY KEY (`id_categoria`),
  UNIQUE KEY `nome` (`nome`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categoria`
--

LOCK TABLES `categoria` WRITE;
/*!40000 ALTER TABLE `categoria` DISABLE KEYS */;
INSERT INTO `categoria` VALUES (4,'Fitness'),(1,'Moda Feminina'),(3,'Moda Infantil'),(2,'Moda Masculina'),(5,'Praia');
/*!40000 ALTER TABLE `categoria` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cenario_concorrencia`
--

DROP TABLE IF EXISTS `cenario_concorrencia`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cenario_concorrencia` (
  `id_cenario` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(100) NOT NULL,
  `percentual_impacto` decimal(5,2) NOT NULL,
  `descricao` varchar(300) DEFAULT NULL,
  `id_usuario` int NOT NULL,
  `id_categoria` int DEFAULT NULL,
  PRIMARY KEY (`id_cenario`),
  KEY `id_usuario` (`id_usuario`),
  KEY `id_categoria` (`id_categoria`),
  CONSTRAINT `cenario_concorrencia_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `usuario` (`id_usuario`),
  CONSTRAINT `cenario_concorrencia_ibfk_2` FOREIGN KEY (`id_categoria`) REFERENCES `categoria` (`id_categoria`),
  CONSTRAINT `chk_cenario_impacto` CHECK (((`percentual_impacto` >= 0) and (`percentual_impacto` <= 100)))
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cenario_concorrencia`
--

LOCK TABLES `cenario_concorrencia` WRITE;
/*!40000 ALTER TABLE `cenario_concorrencia` DISABLE KEYS */;
INSERT INTO `cenario_concorrencia` VALUES (1,'Aumento da concorrencia',10.00,'Simulacao de aumento da concorrencia no mercado.',2,1),(2,'Entrada de novo concorrente',15.00,'Simulacao da entrada de uma nova confeccao na regiao.',3,2),(3,'Queda de demanda',8.00,'Simulacao de reducao da demanda pela categoria.',5,4),(4,'Expansao regional',12.50,'Simulacao de crescimento da demanda em novos mercados.',1,NULL);
/*!40000 ALTER TABLE `cenario_concorrencia` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cidade`
--

DROP TABLE IF EXISTS `cidade`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cidade` (
  `id_cidade` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(80) NOT NULL,
  `uf` char(2) NOT NULL,
  `polo_destaque` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_cidade`),
  CONSTRAINT `chk_cidade_polo` CHECK ((`polo_destaque` in (0,1)))
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cidade`
--

LOCK TABLES `cidade` WRITE;
/*!40000 ALTER TABLE `cidade` DISABLE KEYS */;
INSERT INTO `cidade` VALUES (1,'Recife','PE',0),(2,'Caruaru','PE',1),(3,'Joao Pessoa','PB',0),(4,'Maceio','AL',0),(5,'Toritama','PE',1),(6,'Santa Cruz do Capibaribe','PE',1),(7,'Olinda','PE',1),(8,'Passira','PE',1);
/*!40000 ALTER TABLE `cidade` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `confeccao`
--

DROP TABLE IF EXISTS `confeccao`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `confeccao` (
  `id_confeccao` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(120) NOT NULL,
  `cnpj` varchar(14) DEFAULT NULL,
  `porte` varchar(10) NOT NULL,
  `tipo` varchar(10) NOT NULL,
  `id_cidade` int NOT NULL,
  PRIMARY KEY (`id_confeccao`),
  UNIQUE KEY `cnpj` (`cnpj`),
  KEY `idx_confeccao_cidade` (`id_cidade`),
  CONSTRAINT `confeccao_ibfk_1` FOREIGN KEY (`id_cidade`) REFERENCES `cidade` (`id_cidade`),
  CONSTRAINT `chk_confeccao_porte` CHECK ((`porte` in (_utf8mb4'MICRO',_utf8mb4'PEQUENA',_utf8mb4'MEDIA'))),
  CONSTRAINT `chk_confeccao_tipo` CHECK ((`tipo` in (_utf8mb4'CONFECCAO',_utf8mb4'FACCAO')))
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `confeccao`
--

LOCK TABLES `confeccao` WRITE;
/*!40000 ALTER TABLE `confeccao` DISABLE KEYS */;
INSERT INTO `confeccao` VALUES (1,'Moda Recife','12345678000101','MEDIA','CONFECCAO',1),(2,'Estilo Agreste','23456789000102','PEQUENA','CONFECCAO',2),(3,'Costura Nordeste','34567890000103','MICRO','FACCAO',2),(4,'Paraiba Fashion','45678901000104','PEQUENA','CONFECCAO',3),(5,'Alagoas Textil','56789012000105','MEDIA','CONFECCAO',4),(6,'Jeans Toritama','67890123000106','PEQUENA','CONFECCAO',5),(7,'Moda Santa Cruz','78901234000107','MEDIA','CONFECCAO',6),(8,'Atelier Olinda','89012345000108','MICRO','FACCAO',7),(9,'Passira Artesanal','90123456000109','MICRO','FACCAO',8);
/*!40000 ALTER TABLE `confeccao` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `entrevista`
--

DROP TABLE IF EXISTS `entrevista`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `entrevista` (
  `id_entrevista` int NOT NULL AUTO_INCREMENT,
  `data` date NOT NULL,
  `resumo` text NOT NULL,
  `achou_algo_novo` varchar(3) NOT NULL,
  `id_confeccao` int NOT NULL,
  `id_categoria_percebida` int DEFAULT NULL,
  PRIMARY KEY (`id_entrevista`),
  KEY `id_confeccao` (`id_confeccao`),
  KEY `id_categoria_percebida` (`id_categoria_percebida`),
  CONSTRAINT `entrevista_ibfk_1` FOREIGN KEY (`id_confeccao`) REFERENCES `confeccao` (`id_confeccao`),
  CONSTRAINT `entrevista_ibfk_2` FOREIGN KEY (`id_categoria_percebida`) REFERENCES `categoria` (`id_categoria`),
  CONSTRAINT `chk_entrevista_novo` CHECK ((`achou_algo_novo` in (_utf8mb4'SIM',_utf8mb4'NAO')))
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `entrevista`
--

LOCK TABLES `entrevista` WRITE;
/*!40000 ALTER TABLE `entrevista` DISABLE KEYS */;
INSERT INTO `entrevista` VALUES (1,'2026-01-15','A empresa identificou aumento da procura por moda feminina.','SIM',1,1),(2,'2026-01-20','A empresa relatou estabilidade nas vendas de moda masculina.','NAO',2,2),(3,'2026-02-10','Foi identificada maior procura por produtos fitness.','SIM',4,4),(4,'2026-02-18','A empresa percebeu crescimento nas vendas de moda praia.','SIM',5,5),(5,'2026-03-05','Nao foram identificadas novas tendencias relevantes.','NAO',3,NULL);
/*!40000 ALTER TABLE `entrevista` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `historico_preco_produto`
--

DROP TABLE IF EXISTS `historico_preco_produto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `historico_preco_produto` (
  `id` int NOT NULL AUTO_INCREMENT,
  `produto_id` int NOT NULL,
  `preco_anterior` decimal(10,2) NOT NULL,
  `preco_novo` decimal(10,2) NOT NULL,
  `justificativa` varchar(255) DEFAULT NULL,
  `alterado_por` int DEFAULT NULL,
  `usuario_mysql` varchar(100) DEFAULT NULL,
  `data_alteracao` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_hist_preco_produto_data` (`produto_id`,`data_alteracao`),
  KEY `alterado_por` (`alterado_por`),
  CONSTRAINT `historico_preco_produto_ibfk_1` FOREIGN KEY (`produto_id`) REFERENCES `produto` (`id_produto`) ON DELETE RESTRICT,
  CONSTRAINT `historico_preco_produto_ibfk_2` FOREIGN KEY (`alterado_por`) REFERENCES `usuario` (`id_usuario`) ON DELETE RESTRICT,
  CONSTRAINT `chk_hist_preco_diferente` CHECK ((`preco_anterior` <> `preco_novo`)),
  CONSTRAINT `chk_hist_preco_valores` CHECK (((`preco_anterior` >= 0) and (`preco_novo` >= 0)))
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `historico_preco_produto`
--

LOCK TABLES `historico_preco_produto` WRITE;
/*!40000 ALTER TABLE `historico_preco_produto` DISABLE KEYS */;
INSERT INTO `historico_preco_produto` VALUES (1,1,80.00,95.00,NULL,4,'root@localhost','2026-11-18 17:23:23');
/*!40000 ALTER TABLE `historico_preco_produto` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `importacao`
--

DROP TABLE IF EXISTS `importacao`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `importacao` (
  `id_importacao` int NOT NULL AUTO_INCREMENT,
  `nome_arquivo` varchar(150) NOT NULL,
  `data_importacao` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `qtd_linhas` int DEFAULT NULL,
  `imp_status` varchar(10) NOT NULL,
  `id_usuario` int NOT NULL,
  PRIMARY KEY (`id_importacao`),
  KEY `id_usuario` (`id_usuario`),
  CONSTRAINT `importacao_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `usuario` (`id_usuario`),
  CONSTRAINT `chk_imp_status` CHECK ((`imp_status` in (_utf8mb4'CONCLUIDA',_utf8mb4'ERRO')))
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `importacao`
--

LOCK TABLES `importacao` WRITE;
/*!40000 ALTER TABLE `importacao` DISABLE KEYS */;
INSERT INTO `importacao` VALUES (1,'vendas_jan_fev_modarecife.csv','2026-03-01 09:15:00',2,'CONCLUIDA',2),(2,'vendas_jan_fev_estiloagreste.csv','2026-03-01 10:20:00',2,'CONCLUIDA',3),(3,'vendas_janeiro_costuranordeste.csv','2026-02-01 14:30:00',1,'CONCLUIDA',4),(4,'vendas_janeiro_paraibafashion.csv','2026-02-01 08:45:00',1,'CONCLUIDA',5),(5,'vendas_marco_modarecife.csv','2026-11-18 17:23:23',2,'CONCLUIDA',2),(7,'vendas_marco_estiloagreste.csv','2026-11-18 17:23:23',NULL,'ERRO',3);
/*!40000 ALTER TABLE `importacao` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `item_relatorio`
--

DROP TABLE IF EXISTS `item_relatorio`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `item_relatorio` (
  `id_item` int NOT NULL AUTO_INCREMENT,
  `uf` char(2) DEFAULT NULL,
  `quantidade` int NOT NULL,
  `faturamento` decimal(12,2) NOT NULL,
  `variacao_percentual` decimal(7,2) DEFAULT NULL,
  `tendencia` varchar(10) DEFAULT NULL,
  `id_relatorio` int NOT NULL,
  `id_categoria` int DEFAULT NULL,
  PRIMARY KEY (`id_item`),
  KEY `id_relatorio` (`id_relatorio`),
  KEY `id_categoria` (`id_categoria`),
  CONSTRAINT `item_relatorio_ibfk_1` FOREIGN KEY (`id_relatorio`) REFERENCES `relatorio` (`id_relatorio`),
  CONSTRAINT `item_relatorio_ibfk_2` FOREIGN KEY (`id_categoria`) REFERENCES `categoria` (`id_categoria`),
  CONSTRAINT `chk_item_tendencia` CHECK (((`tendencia` is null) or (`tendencia` in (_utf8mb4'ALTA',_utf8mb4'QUEDA',_utf8mb4'ESTAVEL')))),
  CONSTRAINT `chk_item_uf` CHECK (((`uf` is null) or (`uf` in (_utf8mb4'PE',_utf8mb4'PB',_utf8mb4'AL'))))
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `item_relatorio`
--

LOCK TABLES `item_relatorio` WRITE;
/*!40000 ALTER TABLE `item_relatorio` DISABLE KEYS */;
INSERT INTO `item_relatorio` VALUES (1,'PE',960,67200.00,8.50,'ALTA',1,1),(2,'PB',300,21000.00,3.20,'ESTAVEL',1,2),(3,'AL',390,27300.00,-4.50,'QUEDA',1,5),(4,'PE',730,44700.00,12.00,'ALTA',2,1),(5,'PE',180,10800.00,-2.50,'QUEDA',2,3),(6,'PB',300,21000.00,6.80,'ALTA',2,2),(7,'PE',960,67200.00,8.50,'ALTA',3,1),(8,'PB',300,21000.00,3.20,'ESTAVEL',3,2),(9,'PE',1050,74700.00,10.50,'ALTA',4,1),(10,'PB',300,21000.00,5.00,'ALTA',4,2),(11,'PE',2880,193500.00,NULL,NULL,5,NULL),(12,'PB',650,45500.00,NULL,NULL,5,NULL),(14,'AL',810,56700.00,NULL,NULL,5,NULL);
/*!40000 ALTER TABLE `item_relatorio` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lancamento_mensal`
--

DROP TABLE IF EXISTS `lancamento_mensal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lancamento_mensal` (
  `id_lancamento` int NOT NULL AUTO_INCREMENT,
  `mes_referencia` date NOT NULL,
  `quantidade` int NOT NULL,
  `faturamento` decimal(12,2) NOT NULL,
  `origem` varchar(10) NOT NULL,
  `lanc_status` varchar(10) NOT NULL DEFAULT 'ATIVO',
  `id_confeccao` int NOT NULL,
  `id_categoria` int NOT NULL,
  `id_importacao` int DEFAULT NULL,
  PRIMARY KEY (`id_lancamento`),
  UNIQUE KEY `id_confeccao` (`id_confeccao`,`id_categoria`,`mes_referencia`),
  KEY `idx_lanc_status_mes` (`lanc_status`,`mes_referencia`),
  KEY `idx_lanc_polo` (`lanc_status`,`id_confeccao`,`quantidade`,`faturamento`),
  KEY `id_categoria` (`id_categoria`),
  KEY `id_importacao` (`id_importacao`),
  CONSTRAINT `lancamento_mensal_ibfk_1` FOREIGN KEY (`id_confeccao`) REFERENCES `confeccao` (`id_confeccao`),
  CONSTRAINT `lancamento_mensal_ibfk_2` FOREIGN KEY (`id_categoria`) REFERENCES `categoria` (`id_categoria`),
  CONSTRAINT `lancamento_mensal_ibfk_3` FOREIGN KEY (`id_importacao`) REFERENCES `importacao` (`id_importacao`),
  CONSTRAINT `chk_lanc_dia1` CHECK ((dayofmonth(`mes_referencia`) = 1)),
  CONSTRAINT `chk_lanc_fatur` CHECK ((`faturamento` >= 0)),
  CONSTRAINT `chk_lanc_origem` CHECK ((`origem` in (_utf8mb4'MANUAL',_utf8mb4'IMPORTACAO'))),
  CONSTRAINT `chk_lanc_origem_importacao` CHECK ((((`origem` = _utf8mb4'IMPORTACAO') and (`id_importacao` is not null)) or ((`origem` = _utf8mb4'MANUAL') and (`id_importacao` is null)))),
  CONSTRAINT `chk_lanc_quant` CHECK ((`quantidade` >= 0)),
  CONSTRAINT `chk_lanc_status` CHECK ((`lanc_status` in (_utf8mb4'ATIVO',_utf8mb4'CANCELADO')))
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lancamento_mensal`
--

LOCK TABLES `lancamento_mensal` WRITE;
/*!40000 ALTER TABLE `lancamento_mensal` DISABLE KEYS */;
INSERT INTO `lancamento_mensal` VALUES (1,'2026-01-01',450,31500.00,'IMPORTACAO','ATIVO',1,1,1),(2,'2026-01-01',280,19600.00,'MANUAL','ATIVO',1,2,NULL),(3,'2026-02-01',510,35700.00,'IMPORTACAO','ATIVO',1,1,1),(4,'2026-01-01',220,13200.00,'IMPORTACAO','ATIVO',2,1,2),(5,'2026-01-01',180,10800.00,'MANUAL','ATIVO',2,3,NULL),(6,'2026-02-01',250,15000.00,'IMPORTACAO','ATIVO',2,1,2),(7,'2026-01-01',160,9600.00,'IMPORTACAO','ATIVO',3,2,3),(8,'2026-02-01',190,11400.00,'MANUAL','CANCELADO',3,2,NULL),(9,'2026-01-01',300,21000.00,'IMPORTACAO','ATIVO',4,4,4),(10,'2026-02-01',350,24500.00,'MANUAL','ATIVO',4,4,NULL),(11,'2026-01-01',390,27300.00,'MANUAL','ATIVO',5,5,NULL),(12,'2026-02-01',420,29400.00,'MANUAL','ATIVO',5,5,NULL),(13,'2026-01-01',520,31200.00,'MANUAL','ATIVO',6,2,NULL),(14,'2026-02-01',610,36600.00,'MANUAL','ATIVO',6,2,NULL),(15,'2026-01-01',480,28800.00,'MANUAL','ATIVO',7,1,NULL),(16,'2026-02-01',530,31800.00,'MANUAL','ATIVO',7,1,NULL),(17,'2026-01-01',90,7200.00,'MANUAL','ATIVO',8,3,NULL),(18,'2026-02-01',110,8800.00,'MANUAL','ATIVO',8,3,NULL),(19,'2026-01-01',60,4800.00,'MANUAL','ATIVO',9,3,NULL),(20,'2026-02-01',75,6000.00,'MANUAL','ATIVO',9,3,NULL),(22,'2026-03-01',530,37100.00,'IMPORTACAO','ATIVO',1,1,5),(23,'2026-03-01',300,21000.00,'IMPORTACAO','ATIVO',1,2,5);
/*!40000 ALTER TABLE `lancamento_mensal` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `trg_log_lancamento_update` AFTER UPDATE ON `lancamento_mensal` FOR EACH ROW BEGIN
    INSERT INTO log_lancamento
    (id_lancamento, acao, quantidade_antiga, faturamento_antigo, status_antigo,
     quantidade_nova, faturamento_novo, status_novo, usuario_mysql)
    VALUES
    (OLD.id_lancamento, 'UPDATE', OLD.quantidade, OLD.faturamento, OLD.lanc_status,
     NEW.quantidade, NEW.faturamento, NEW.lanc_status, CURRENT_USER());
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `trg_log_lancamento_delete` AFTER DELETE ON `lancamento_mensal` FOR EACH ROW BEGIN
    INSERT INTO log_lancamento
    (id_lancamento, acao, quantidade_antiga, faturamento_antigo, status_antigo,
     usuario_mysql)
    VALUES
    (OLD.id_lancamento, 'DELETE', OLD.quantidade, OLD.faturamento, OLD.lanc_status,
     CURRENT_USER());
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `log_lancamento`
--

DROP TABLE IF EXISTS `log_lancamento`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `log_lancamento` (
  `id_log` int NOT NULL AUTO_INCREMENT,
  `id_lancamento` int NOT NULL,
  `acao` varchar(10) NOT NULL,
  `quantidade_antiga` int NOT NULL,
  `faturamento_antigo` decimal(12,2) NOT NULL,
  `status_antigo` varchar(10) NOT NULL,
  `quantidade_nova` int DEFAULT NULL,
  `faturamento_novo` decimal(12,2) DEFAULT NULL,
  `status_novo` varchar(10) DEFAULT NULL,
  `usuario_mysql` varchar(100) DEFAULT NULL,
  `data_log` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_log`),
  CONSTRAINT `chk_log_acao` CHECK ((`acao` in (_utf8mb4'UPDATE',_utf8mb4'DELETE')))
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_lancamento`
--

LOCK TABLES `log_lancamento` WRITE;
/*!40000 ALTER TABLE `log_lancamento` DISABLE KEYS */;
INSERT INTO `log_lancamento` VALUES (1,10,'UPDATE',340,23800.00,'ATIVO',350,24500.00,'ATIVO','root@localhost','2026-11-18 17:23:23'),(2,8,'UPDATE',190,11400.00,'ATIVO',190,11400.00,'CANCELADO','root@localhost','2026-11-18 17:23:23'),(3,21,'DELETE',360,25200.00,'ATIVO',NULL,NULL,NULL,'root@localhost','2026-11-18 17:23:23');
/*!40000 ALTER TABLE `log_lancamento` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pedido`
--

DROP TABLE IF EXISTS `pedido`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pedido` (
  `id_pedido` int NOT NULL AUTO_INCREMENT,
  `data_pedido` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `ped_status` varchar(12) NOT NULL DEFAULT 'PENDENTE',
  `data_entrega` datetime DEFAULT NULL,
  `id_usuario` int NOT NULL,
  `id_confeccao` int NOT NULL,
  PRIMARY KEY (`id_pedido`),
  UNIQUE KEY `id_pedido` (`id_pedido`,`id_confeccao`),
  KEY `idx_pedido_data` (`data_pedido`),
  KEY `idx_pedido_confeccao_status` (`id_confeccao`,`ped_status`),
  KEY `id_usuario` (`id_usuario`),
  CONSTRAINT `pedido_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `usuario` (`id_usuario`),
  CONSTRAINT `pedido_ibfk_2` FOREIGN KEY (`id_confeccao`) REFERENCES `confeccao` (`id_confeccao`),
  CONSTRAINT `chk_ped_entrega` CHECK ((((`ped_status` = _utf8mb4'ENTREGUE') and (`data_entrega` is not null)) or ((`ped_status` <> _utf8mb4'ENTREGUE') and (`data_entrega` is null)))),
  CONSTRAINT `chk_ped_status` CHECK ((`ped_status` in (_utf8mb4'PENDENTE',_utf8mb4'EM_TRANSITO',_utf8mb4'ENTREGUE',_utf8mb4'CANCELADO')))
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pedido`
--

LOCK TABLES `pedido` WRITE;
/*!40000 ALTER TABLE `pedido` DISABLE KEYS */;
INSERT INTO `pedido` VALUES (1,'2026-02-02 10:00:00','ENTREGUE','2026-02-09 15:30:00',2,3),(2,'2026-02-10 11:20:00','ENTREGUE','2026-02-17 09:00:00',3,3),(3,'2026-03-01 08:40:00','PENDENTE',NULL,5,1),(4,'2026-01-10 09:00:00','ENTREGUE','2026-01-17 10:00:00',2,2),(5,'2026-01-20 14:00:00','ENTREGUE','2026-01-28 16:00:00',3,6),(6,'2026-02-05 10:30:00','EM_TRANSITO',NULL,2,7),(7,'2026-02-12 08:15:00','ENTREGUE','2026-02-20 11:00:00',5,8),(8,'2026-02-25 13:45:00','PENDENTE',NULL,4,9),(9,'2026-03-03 09:20:00','CANCELADO',NULL,6,6),(10,'2026-03-08 15:00:00','ENTREGUE','2026-03-15 09:30:00',2,7),(11,'2026-03-10 10:10:00','ENTREGUE','2026-03-18 14:00:00',3,2);
/*!40000 ALTER TABLE `pedido` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `produto`
--

DROP TABLE IF EXISTS `produto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `produto` (
  `id_produto` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(120) NOT NULL,
  `preco` decimal(10,2) NOT NULL,
  `justificativa_preco` varchar(255) DEFAULT NULL,
  `id_confeccao` int NOT NULL,
  PRIMARY KEY (`id_produto`),
  KEY `id_confeccao` (`id_confeccao`),
  CONSTRAINT `produto_ibfk_1` FOREIGN KEY (`id_confeccao`) REFERENCES `confeccao` (`id_confeccao`),
  CONSTRAINT `chk_produto_preco` CHECK ((`preco` >= 0))
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `produto`
--

LOCK TABLES `produto` WRITE;
/*!40000 ALTER TABLE `produto` DISABLE KEYS */;
INSERT INTO `produto` VALUES (1,'Camiseta bordada a mao',95.00,NULL,3),(2,'Bolsa de palha trancada',120.00,NULL,9),(3,'Vestido de renda',250.00,NULL,8),(4,'Bermuda jeans lavada',95.00,NULL,6),(5,'Blusa de croche',70.00,NULL,7);
/*!40000 ALTER TABLE `produto` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `trg_audita_preco_produto` BEFORE UPDATE ON `produto` FOR EACH ROW BEGIN
    IF OLD.preco <> NEW.preco THEN
        IF NEW.preco < 0 THEN
            SIGNAL SQLSTATE '45000'
                SET MESSAGE_TEXT = 'Preco nao pode ser negativo.';
        END IF;

        IF OLD.preco > 0
           AND NEW.preco > OLD.preco * 3
           AND (NEW.justificativa_preco IS NULL OR TRIM(NEW.justificativa_preco) = '') THEN
            SIGNAL SQLSTATE '45000'
                SET MESSAGE_TEXT = 'Acrescimo acima de 200% exige justificativa.';
        END IF;

        INSERT INTO historico_preco_produto
        (produto_id, preco_anterior, preco_novo, justificativa, alterado_por, usuario_mysql)
        VALUES
        (OLD.id_produto, OLD.preco, NEW.preco, NULLIF(TRIM(NEW.justificativa_preco), ''),
         @id_usuario_logado, CURRENT_USER());
    END IF;

    SET NEW.justificativa_preco = NULL;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `relatorio`
--

DROP TABLE IF EXISTS `relatorio`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `relatorio` (
  `id_relatorio` int NOT NULL AUTO_INCREMENT,
  `tipo` varchar(20) NOT NULL,
  `periodo_inicio` date NOT NULL,
  `periodo_fim` date NOT NULL,
  `limiar_tendencia` decimal(5,2) DEFAULT NULL,
  `data_geracao` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `id_usuario` int NOT NULL,
  `id_cenario` int DEFAULT NULL,
  PRIMARY KEY (`id_relatorio`),
  KEY `id_usuario` (`id_usuario`),
  KEY `id_cenario` (`id_cenario`),
  CONSTRAINT `relatorio_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `usuario` (`id_usuario`),
  CONSTRAINT `relatorio_ibfk_2` FOREIGN KEY (`id_cenario`) REFERENCES `cenario_concorrencia` (`id_cenario`),
  CONSTRAINT `chk_relatorio_cenario` CHECK ((((`tipo` = _utf8mb4'CENARIO') and (`id_cenario` is not null)) or ((`tipo` <> _utf8mb4'CENARIO') and (`id_cenario` is null)))),
  CONSTRAINT `chk_relatorio_periodo` CHECK ((`periodo_fim` >= `periodo_inicio`)),
  CONSTRAINT `chk_relatorio_tipo` CHECK ((`tipo` in (_utf8mb4'REGIONAL',_utf8mb4'CATEGORIA_PERIODO',_utf8mb4'TENDENCIA',_utf8mb4'CENARIO')))
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `relatorio`
--

LOCK TABLES `relatorio` WRITE;
/*!40000 ALTER TABLE `relatorio` DISABLE KEYS */;
INSERT INTO `relatorio` VALUES (1,'REGIONAL','2026-01-01','2026-03-31',5.00,'2026-04-05 09:00:00',1,NULL),(2,'CATEGORIA_PERIODO','2026-01-01','2026-03-31',10.00,'2026-04-06 10:30:00',1,NULL),(3,'TENDENCIA','2026-01-01','2026-03-31',5.00,'2026-04-07 14:00:00',2,NULL),(4,'CENARIO','2026-01-01','2026-03-31',NULL,'2026-04-08 15:30:00',3,1),(5,'REGIONAL','2026-01-01','2026-03-31',5.00,'2026-11-18 17:23:23',1,NULL);
/*!40000 ALTER TABLE `relatorio` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuario`
--

DROP TABLE IF EXISTS `usuario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usuario` (
  `id_usuario` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(100) NOT NULL,
  `email` varchar(120) NOT NULL,
  `senha_hash` varchar(255) NOT NULL,
  `perfil` varchar(10) NOT NULL,
  `id_confeccao` int DEFAULT NULL,
  PRIMARY KEY (`id_usuario`),
  UNIQUE KEY `email` (`email`),
  KEY `id_confeccao` (`id_confeccao`),
  CONSTRAINT `usuario_ibfk_1` FOREIGN KEY (`id_confeccao`) REFERENCES `confeccao` (`id_confeccao`),
  CONSTRAINT `chk_usuario_perfil` CHECK ((`perfil` in (_utf8mb4'ADMIN',_utf8mb4'EMPRESARIO'))),
  CONSTRAINT `chk_usuario_perfil_confeccao` CHECK ((((`perfil` = _utf8mb4'ADMIN') and (`id_confeccao` is null)) or ((`perfil` = _utf8mb4'EMPRESARIO') and (`id_confeccao` is not null))))
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuario`
--

LOCK TABLES `usuario` WRITE;
/*!40000 ALTER TABLE `usuario` DISABLE KEYS */;
INSERT INTO `usuario` VALUES (1,'Administrador','admin@confeccoes.com','HASH_ADMIN_123','ADMIN',NULL),(2,'Ana Silva','ana@modarecife.com','HASH_ANA_123','EMPRESARIO',1),(3,'Bruno Santos','bruno@estiloagreste.com','HASH_BRUNO_123','EMPRESARIO',2),(4,'Carla Oliveira','carla@costuranordeste.com','HASH_CARLA_123','EMPRESARIO',3),(5,'Daniel Lima','daniel@paraibafashion.com','HASH_DANIEL_123','EMPRESARIO',4),(6,'Eduarda Costa','eduarda@alagoastextil.com','HASH_EDUARDA_123','EMPRESARIO',5);
/*!40000 ALTER TABLE `usuario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `vw_lancamentos`
--

DROP TABLE IF EXISTS `vw_lancamentos`;
/*!50001 DROP VIEW IF EXISTS `vw_lancamentos`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `vw_lancamentos` AS SELECT 
 1 AS `id_lancamento`,
 1 AS `mes_referencia`,
 1 AS `quantidade`,
 1 AS `faturamento`,
 1 AS `origem`,
 1 AS `lanc_status`,
 1 AS `id_confeccao`,
 1 AS `confeccao`,
 1 AS `id_categoria`,
 1 AS `categoria`,
 1 AS `cidade`,
 1 AS `uf`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `vw_reputacao_artesao`
--

DROP TABLE IF EXISTS `vw_reputacao_artesao`;
/*!50001 DROP VIEW IF EXISTS `vw_reputacao_artesao`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `vw_reputacao_artesao` AS SELECT 
 1 AS `artesao_id`,
 1 AS `artesao`,
 1 AS `cidade`,
 1 AS `uf`,
 1 AS `nota_media`,
 1 AS `total_avaliacoes`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `vw_vendas_polo_regional`
--

DROP TABLE IF EXISTS `vw_vendas_polo_regional`;
/*!50001 DROP VIEW IF EXISTS `vw_vendas_polo_regional`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `vw_vendas_polo_regional` AS SELECT 
 1 AS `municipio_id`,
 1 AS `municipio`,
 1 AS `uf`,
 1 AS `polo_destaque`,
 1 AS `faturamento_total`,
 1 AS `volume_itens`,
 1 AS `qtd_pedidos`,
 1 AS `ticket_medio_item`*/;
SET character_set_client = @saved_cs_client;

--
-- Dumping events for database 'confeccoes'
--

--
-- Dumping routines for database 'confeccoes'
--
/*!50003 DROP PROCEDURE IF EXISTS `atualizar_lancamento` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `atualizar_lancamento`(
    IN p_id_lancamento INT,
    IN p_quantidade INT,
    IN p_faturamento DECIMAL(12,2)
)
BEGIN
    DECLARE v_status VARCHAR(10);

    SELECT lanc_status INTO v_status
    FROM lancamento_mensal
    WHERE id_lancamento = p_id_lancamento;

    IF v_status IS NULL THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Lancamento nao encontrado.';
    ELSEIF v_status = 'CANCELADO' THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Lancamento cancelado nao pode ser atualizado.';
    END IF;

    UPDATE lancamento_mensal
    SET quantidade = p_quantidade,
        faturamento = p_faturamento
    WHERE id_lancamento = p_id_lancamento;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `cancelar_lancamento` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `cancelar_lancamento`(
    IN p_id_lancamento INT
)
BEGIN
    UPDATE lancamento_mensal
    SET lanc_status = 'CANCELADO'
    WHERE id_lancamento = p_id_lancamento;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `excluir_lancamento` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `excluir_lancamento`(
    IN p_id_lancamento INT
)
BEGIN
    DELETE FROM lancamento_mensal
    WHERE id_lancamento = p_id_lancamento;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `gerar_relatorio_regional` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `gerar_relatorio_regional`(
    IN p_id_usuario INT,
    IN p_periodo_inicio DATE,
    IN p_periodo_fim DATE,
    IN p_limiar DECIMAL(5,2)
)
BEGIN
    DECLARE v_id_relatorio INT;
    DECLARE v_meses INT;
    DECLARE v_ant_inicio DATE;
    DECLARE v_ant_fim DATE;

    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;

    SET v_meses = TIMESTAMPDIFF(MONTH, p_periodo_inicio, p_periodo_fim) + 1;
    SET v_ant_inicio = DATE_SUB(p_periodo_inicio, INTERVAL v_meses MONTH);
    SET v_ant_fim = DATE_SUB(p_periodo_inicio, INTERVAL 1 DAY);

    START TRANSACTION;

    INSERT INTO relatorio (tipo, periodo_inicio, periodo_fim, limiar_tendencia, id_usuario)
    VALUES ('REGIONAL', p_periodo_inicio, p_periodo_fim, p_limiar, p_id_usuario);
    SET v_id_relatorio = LAST_INSERT_ID();

    INSERT INTO item_relatorio
    (uf, quantidade, faturamento, variacao_percentual, tendencia, id_relatorio)
    SELECT a.uf, a.quantidade, a.faturamento, a.variacao,
           CASE WHEN a.variacao IS NULL THEN NULL
                WHEN a.variacao > p_limiar THEN 'ALTA'
                WHEN a.variacao < -p_limiar THEN 'QUEDA'
                ELSE 'ESTAVEL'
           END,
           v_id_relatorio
    FROM (
        SELECT atual.uf, atual.quantidade, atual.faturamento,
               CASE WHEN ant.faturamento IS NULL OR ant.faturamento = 0 THEN NULL
                    ELSE ROUND((atual.faturamento - ant.faturamento) / ant.faturamento * 100, 2)
               END AS variacao
        FROM (SELECT uf, SUM(quantidade) AS quantidade, SUM(faturamento) AS faturamento
              FROM vw_lancamentos
              WHERE mes_referencia BETWEEN p_periodo_inicio AND p_periodo_fim
              GROUP BY uf) atual
        LEFT JOIN (SELECT uf, SUM(faturamento) AS faturamento
                   FROM vw_lancamentos
                   WHERE mes_referencia BETWEEN v_ant_inicio AND v_ant_fim
                   GROUP BY uf) ant ON ant.uf = atual.uf
    ) a;

    IF ROW_COUNT() = 0 THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Periodo sem lancamentos ativos: relatorio nao gerado.';
    END IF;

    COMMIT;
    SELECT v_id_relatorio AS id_relatorio;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `inserir_lancamento` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `inserir_lancamento`(
    IN p_mes_referencia DATE,
    IN p_quantidade INT,
    IN p_faturamento DECIMAL(12,2),
    IN p_id_confeccao INT,
    IN p_id_categoria INT
)
BEGIN
    INSERT INTO lancamento_mensal
    (mes_referencia, quantidade, faturamento, origem, lanc_status,
     id_confeccao, id_categoria, id_importacao)
    VALUES
    (DATE_FORMAT(p_mes_referencia, '%Y-%m-01'), p_quantidade, p_faturamento,
     'MANUAL', 'ATIVO', p_id_confeccao, p_id_categoria, NULL);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Final view structure for view `vw_lancamentos`
--

/*!50001 DROP VIEW IF EXISTS `vw_lancamentos`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_lancamentos` AS select `l`.`id_lancamento` AS `id_lancamento`,`l`.`mes_referencia` AS `mes_referencia`,`l`.`quantidade` AS `quantidade`,`l`.`faturamento` AS `faturamento`,`l`.`origem` AS `origem`,`l`.`lanc_status` AS `lanc_status`,`c`.`id_confeccao` AS `id_confeccao`,`c`.`nome` AS `confeccao`,`cat`.`id_categoria` AS `id_categoria`,`cat`.`nome` AS `categoria`,`ci`.`nome` AS `cidade`,`ci`.`uf` AS `uf` from (((`lancamento_mensal` `l` join `confeccao` `c` on((`l`.`id_confeccao` = `c`.`id_confeccao`))) join `categoria` `cat` on((`l`.`id_categoria` = `cat`.`id_categoria`))) join `cidade` `ci` on((`c`.`id_cidade` = `ci`.`id_cidade`))) where (`l`.`lanc_status` = 'ATIVO') */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vw_reputacao_artesao`
--

/*!50001 DROP VIEW IF EXISTS `vw_reputacao_artesao`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_reputacao_artesao` AS select `c`.`id_confeccao` AS `artesao_id`,`c`.`nome` AS `artesao`,`ci`.`nome` AS `cidade`,`ci`.`uf` AS `uf`,round(avg(`a`.`nota`),2) AS `nota_media`,count(`a`.`id`) AS `total_avaliacoes` from ((`confeccao` `c` join `cidade` `ci` on((`c`.`id_cidade` = `ci`.`id_cidade`))) left join `avaliacoes_artesao` `a` on((`a`.`artesao_id` = `c`.`id_confeccao`))) group by `c`.`id_confeccao`,`c`.`nome`,`ci`.`nome`,`ci`.`uf` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vw_vendas_polo_regional`
--

/*!50001 DROP VIEW IF EXISTS `vw_vendas_polo_regional`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_vendas_polo_regional` AS select `ci`.`id_cidade` AS `municipio_id`,`ci`.`nome` AS `municipio`,`ci`.`uf` AS `uf`,`ci`.`polo_destaque` AS `polo_destaque`,coalesce(`v`.`faturamento_total`,0) AS `faturamento_total`,coalesce(`v`.`volume_itens`,0) AS `volume_itens`,coalesce(`p`.`qtd_pedidos`,0) AS `qtd_pedidos`,round((coalesce(`v`.`faturamento_total`,0) / nullif(`v`.`volume_itens`,0)),2) AS `ticket_medio_item` from ((`cidade` `ci` left join (select `c`.`id_cidade` AS `id_cidade`,sum(`x`.`faturamento`) AS `faturamento_total`,sum(`x`.`quantidade`) AS `volume_itens` from ((select `lancamento_mensal`.`id_confeccao` AS `id_confeccao`,sum(`lancamento_mensal`.`faturamento`) AS `faturamento`,sum(`lancamento_mensal`.`quantidade`) AS `quantidade` from `lancamento_mensal` where (`lancamento_mensal`.`lanc_status` = 'ATIVO') group by `lancamento_mensal`.`id_confeccao`) `x` join `confeccao` `c` on((`c`.`id_confeccao` = `x`.`id_confeccao`))) group by `c`.`id_cidade`) `v` on((`v`.`id_cidade` = `ci`.`id_cidade`))) left join (select `c`.`id_cidade` AS `id_cidade`,count(0) AS `qtd_pedidos` from (`pedido` `pe` join `confeccao` `c` on((`c`.`id_confeccao` = `pe`.`id_confeccao`))) where (`pe`.`ped_status` <> 'CANCELADO') group by `c`.`id_cidade`) `p` on((`p`.`id_cidade` = `ci`.`id_cidade`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-11-19  2:22:11
